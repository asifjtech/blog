document.addEventListener('DOMContentLoaded', function () {
    const postsPerPage = 10;
    let currentPage = 1;

    const posts = document.querySelectorAll('.post');
    const totalPosts = posts.length;
    const totalPages = Math.ceil(totalPosts / postsPerPage);

    function showPage(page) {
        const start = (page - 1) * postsPerPage;
        const end = start + postsPerPage;

        posts.forEach((post, index) => {
            if (index >= start && index < end) {
                post.style.display = 'flex';
            } else {
                post.style.display = 'none';
            }
        });
    }

    showPage(currentPage);

    const paginationLinks = document.querySelector('.pagination');
    for (let i = 1; i <= totalPages; i++) {
        let link = document.createElement('a');
        link.href = '#';
        link.innerText = i;
        link.addEventListener('click', function () {
            currentPage = i;
            showPage(currentPage);
        });
        paginationLinks.appendChild(link);
    }
});
