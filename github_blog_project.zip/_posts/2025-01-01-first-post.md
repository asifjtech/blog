---
layout: post
title: "My First Blog Post"
date: 2025-01-01
image: "/assets/images/first-post.jpg"
excerpt: "This is the introduction to my first blog post. It's a short overview."
---

This is the full content of my first blog post. Here, I talk about all the cool things I plan to write about. Stay tuned for more updates on my blog.

![Blog Image](assets/images/first-post.jpg)
